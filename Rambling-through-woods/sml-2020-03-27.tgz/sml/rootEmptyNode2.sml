fun root Empty = raise Empty_bintree
  | root (Node (x, _, _)) = x
