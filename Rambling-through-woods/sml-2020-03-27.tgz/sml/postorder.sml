local fun post (Empty, Llist) = Llist
        | post (Node (N, LST, RST), Llist) = 
          let val Mlist = post (RST, N::Llist)
              val Nlist = post (LST, Mlist)
          in  Nlist
          end
in fun postorder T = post (T, [])
end
