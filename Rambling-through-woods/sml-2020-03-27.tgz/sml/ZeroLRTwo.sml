datatype 'a bintree0LR2 =
      Zero of 'a |
      OneL of 'a bintree0LR2 * 'a |
      OneR of 'a * 'a bintree0LR2 |
      Two of 'a * 'a bintree0LR2 * 'a bintree0LR2
