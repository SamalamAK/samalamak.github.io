fun BTmap0 T = BTmap (prefix "0") T
fun BTmap1 T = BTmap (prefix "1") T
