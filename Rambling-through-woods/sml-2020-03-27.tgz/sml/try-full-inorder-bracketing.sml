use "basicBinTreeType.sml";
use "BE.sml";
use "BinorderE.sml";
use "bintreeDat.sml";
use "alt-bintreeDat.sml";

val I = BinorderE t1;
val I'=  BinorderE t'3;
I = I';
val I'' = BinorderE t''5;
I' = I'';
I'' = I;
