exception Invalid_Inorder_Traversal
fun makeTreeFromI1 [] = raise  Invalid_Inorder_Traversal
  | makeTreeFromI1 [NONE] = Empty
  | makeTreeFromI1 [_,_] = raise  Invalid_Inorder_Traversal
  | makeTreeFromI1 [NONE, SOME x, NONE] = Node (x, Empty, Empty) (* Inorder *)
  | makeTreeFromI1 [_,_,_] =  raise  Invalid_Inorder_Traversal
  | makeTreeFromI1 I =
    let val arI = Array.fromList I
        val n = Array.length arI
        exception Out_of_Range
        fun areNeighboursI1 ((i,j), (k, m)) =
            let val inRange = (i >= 0) andalso (i < n) andalso
                          (j >= 0) andalso (j < n) andalso
                          (k >= 0) andalso (k < n) andalso
                          (m >= 0) andalso (m < n)
             in if  inRange 
                then if (i<=j) andalso (j<k) andalso (k<= m)
                     then (case Array.sub (arI, j+1) of
                             NONE => false
                           | SOME _ => (k=j+2) (* Inorder *)
                          )
                     else false
                else raise Out_of_Range
             end
        fun findEmptiesIter (ar) = 
            let val i = ref (n-1)
                        (* val NONEs = ref []:((int*int) * 'a option) bintree list ref *)
                        val NONEs = ref []                      
             in while (!i >= 0) do
                ( (case Array.sub (ar, !i) of
                        NONE => NONEs := (Node (((!i,!i), NONE), Empty, Empty))::(!NONEs)
                      | SOME _ => NONEs := !NONEs
                  );
                  i := (!i)-1
                );
                !NONEs           
            end
        val NONEs = findEmptiesIter (arI)
        local
            fun joinNeighboursI [] = []
              | joinNeighboursI [bt] = [bt]
              | joinNeighboursI (bt0::(bt1::btList')) =
                let val ((i,j), rootval0) = root bt0
                    val ((k,m), rootval1) = root bt1
                in  if areNeighboursI1 ((i,j), (k, m))
                    then let val cii = (i, m)
                             val rt  = Array.sub (arI, j+1) (* Inorder *)
                             val bt = Node ((cii, rt), bt0, bt1)
                         in bt::(joinNeighboursI btList')
                         end
                    else bt0::(joinNeighboursI (bt1::btList'))
            end
        in
        fun keepJoiningNeighboursI [] = raise Invalid_Inorder_Traversal
          | keepJoiningNeighboursI [bt] = bt
          | keepJoiningNeighboursI btList = 
            let val btList1 = joinNeighboursI btList 
            in  keepJoiningNeighboursI btList1
            end (* let *)
        end (* local *)
        val bt = keepJoiningNeighboursI NONEs
        exception Unexpected_Empty_Node
        exception Unexpected_Node_Value
        fun eraseIndices Empty = raise Empty_bintree
          | eraseIndices (Node (((i, j), NONE), Empty, Empty)) = 
              if (i=j) then Empty else raise Unexpected_Empty_Node
          | eraseIndices (Node (((i, j), x), LST, RST)) =
              let val left =  eraseIndices LST
                  val right = eraseIndices RST
               in ( case x of 
                         NONE => raise Unexpected_Node_Value
                       | SOME y => Node (y, left, right)
                  )
              end
    in  (eraseIndices bt)
    end
