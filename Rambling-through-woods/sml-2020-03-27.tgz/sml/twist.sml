fun twist Empty = Empty
  | twist (Node (x, LST, RST)) =
    let
        val LST' = twist RST
        val RST' = twist LST
    in  Node (x, LST', RST')
    end     
