fun  is_in (x, L) = List.exists (fn y => x=y) L
exception EmptyList
fun split ([], r) = raise EmptyList
  | split (I', r) =
    let
        fun splitIter ([], r, firsts) = (rev firsts, [])
          | splitIter (h::t, r, firsts) =
            if h = r  then (rev firsts, t)
            else splitIter (t, r, h::firsts)
    in splitIter (I', r, [])
    end
datatype 'a bintree =
         Empty |
         Node of 'a * 'a bintree * 'a bintree
local 
    local
        fun dissemble ([], LI, RI, LP, RP) = (LP, RP):''a list * ''a list
          | dissemble ((h::t), LI, RI, LP, RP) =
            if  is_in (h, LI)
            then dissemble (t, LI, RI, (h::LP), RP)
            else (* it must be in RI *)
                dissemble (t, LI, RI, LP, (h::RP))
    in fun partitions (P', I, r) =
      let
          val (LI, RI) = split (I, r)
          val (LP, RP) = dissemble (P', LI, RI, [], [])
      in (rev LP, LI, rev RP, RI)
      end (* let *)
    end (* local *)
in
fun recover ([], []) = Empty
  | recover ((P as r::P'), I) =
    let (* P and I are permutations of each other *)
        val (LP, LI, RP, RI) = partitions (P', I, r)
        val LST = recover (LP, LI)
        val RST = recover (RP, RI)
    in  Node (r, LST, RST)
    end (* let *)
end (* local *)
