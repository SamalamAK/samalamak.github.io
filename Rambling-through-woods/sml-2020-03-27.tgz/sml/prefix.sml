fun prefix s (x, p) = (x, s^p)
fun prefix0 (x, p) = prefix "0" (x,p)
fun prefix1 (x, p)= prefix "1" (x,p)
