fun rightSubtree Empty = raise Empty_bintree
  | rightSubtree (Node (_, _, RST)) = RST
