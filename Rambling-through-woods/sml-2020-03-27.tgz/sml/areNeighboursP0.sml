fun areNeighboursP0 ((i,j), (k, m)) =
    if (i>0) andalso (i<=j) andalso (j<=k) andalso (k<= m)
    then (case List.nth (P, i-1)
           of NONE => false
            | SOME _ => (k=j+1)
         )
    else false
