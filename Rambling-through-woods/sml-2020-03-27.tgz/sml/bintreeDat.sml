val t7 = Node (7, Empty, Empty)
val t6 = Node (6, t7, Empty);
val t5 = Node (5, Empty, Empty);
val t4 = Node (4, Empty, Empty);
val t3 = Node (3, t5, t6);
val t2 = Node (2, Empty, t4);
val t1 = Node (1, t2, t3);
