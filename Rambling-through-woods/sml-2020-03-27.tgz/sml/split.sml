exception EmptyList
fun split ([], r) = raise EmptyList
  | split (I', r) =
    let
        fun splitIter ([], r, firsts) = (rev firsts, [])
          | splitIter (h::t, r, firsts) =
            if h = r  then (rev firsts, t)
            else splitIter (t, r, h::firsts)
    in splitIter (I', r, [])
    end
