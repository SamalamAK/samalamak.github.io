val t'7 = Node (7, Empty, Empty)
val t'6 = Node (6, t'7, Empty);
val t'5 = Node (5, Empty, Empty);
val t'4 = Node (4, Empty, Empty);
val t'2 = Node (2, Empty, t'4);
val t'1 = Node (1, t'2, t'5);
val t'3 = Node (3, t'1, t'6);

val t''1 = Node (1, Empty, Empty);
val t''2 = Node (2, Empty, Empty);
val t''3 = Node (3, Empty, Empty);
val t''6 = Node (6, Empty, Empty);
val t''4 = Node (4, t''2, t''1);
val t''7 = Node (7, t''3, t''6);
val t''5 = Node (5, t''4, t''7);
