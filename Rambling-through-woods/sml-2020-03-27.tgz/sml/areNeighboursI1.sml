exception Out_of_Range
fun areNeighboursI1 ((i,j), (k, m)) =
    let val inRange = (i >= 0) andalso (i < n) andalso
                  (j >= 0) andalso (j < n) andalso
                  (k >= 0) andalso (k < n) andalso
                  (m >= 0) andalso (m < n)
     in if  inRange 
        then if (i<=j) andalso (j<k) andalso (k<= m)
             then (case Array.sub (arI, j+1) of
                     NONE => false
                   | SOME _ => (k=j+2) (* Inorder *)
                  )
             else false
        else raise Out_of_Range
     end
