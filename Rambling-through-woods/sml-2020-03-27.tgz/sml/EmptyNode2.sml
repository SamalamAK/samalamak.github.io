datatype 'a bintree =
         Empty |
         Node of 'a * 'a bintree * 'a bintree
