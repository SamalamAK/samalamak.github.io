exception invalid_position_string of string
fun partInto3 [] (rt, nl0, nl1) = (rt, nl0, nl1)
  | partInto3 ((a,s)::nl)  (rt, nl0, nl1) =
                if s = "" then partInto3 nl ((a,s)::rt, nl0, nl1)
                else if (String.isPrefix "0" s) then partInto3 nl (rt, (a,s)::nl0, nl1)
                else if (String.isPrefix "1" s) then partInto3 nl (rt, nl0, (a,s)::nl1)
                else raise invalid_position_string (s)
