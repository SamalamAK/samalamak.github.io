fun inorder0 Empty = []
  | inorder0 (Node(x, LST, RST)) = 
        (inorder0 LST) @ [x] @ (inorder0 RST)
