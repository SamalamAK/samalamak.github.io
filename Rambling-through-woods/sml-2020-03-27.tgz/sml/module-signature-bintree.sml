signature BINTREE =
sig
    datatype 'a bintree = Empty |
                          Node of 'a * 'a bintree * 'a bintree
    val root        : 'a bintree -> 'a
    val leftSubtree : 'a bintree -> 'a bintree
    val rightSubtree: 'a bintree -> 'a bintree
    val height      : 'a bintree -> int
    val size        : 'a bintree -> int
    val isLeaf      : 'a bintree -> bool
    val BTmap       : ('a -> 'b) -> 'a bintree -> 'b bintree
    val euler       : 'a bintree -> 'a option list * 'a option list * 'a option list
    val preorder    : 'a bintree -> 'a option list
    val inorder     : 'a bintree -> 'a option list
    val postorder   : 'a bintree -> 'a option list
    exception InvalidPreorderTraversal
    val preorderInverse : 'a option list -> 'a bintree
    val postorderInverse: 'a option list -> 'a bintree
end (* sig *)
