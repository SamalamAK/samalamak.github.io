fun eulerTour0 (Empty) = nil
  | eulerTour0  (Node (x, left, right)) = 
    (PRE x)::((eulerTour0 left)@(IN x)::((eulerTour0 right)@[POST x]))
