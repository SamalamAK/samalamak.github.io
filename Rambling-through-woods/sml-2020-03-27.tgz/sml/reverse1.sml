local 
        fun rev_tr ([], M) = M
          | rev_tr (x::L', M) = rev_tr (L', (x::M))
in
  fun rev L = rev_tr (L, [])
end
