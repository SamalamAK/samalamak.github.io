exception Invalid_Inorder_Traversal
local
    exception Out_of_Range
    exception Unexpected_Constructor
    fun mkbintreeFromA (A, n, i,j) =
      if i < 0 orelse j >= n orelse j <= i
      then raise Out_of_Range
      else if Array.sub (A, i) = B andalso Array.sub (A, j) = E
      then if j=i+1 then Empty
           else (* |(i, j)| = j-i+1 >= 7 *)
               let fun scanLR (i', m, Bcount, Ecount) =
                     if (Ecount > 0 andalso Bcount = Ecount+1)
                     then (i'-1, Array.sub (A, i'))
                     else (case Array.sub (A, i') of
                               B => scanLR (i'+1, m, Bcount+1, Ecount)
                            |  E => scanLR (i'+1, m, Bcount, Ecount+1)
                            | V(_) => scanLR (i'+1, m, Bcount, Ecount)
                          )
                   val (k, v) = scanLR (i, j, 0, 0)
                   (*
                      |(i+1, k)| = k-i >= 2
                      |(k+2, j-1)| = (j-1)-(k+2)+1 = j-k-2 >= 2
                   *)
                   val LST = mkbintreeFromA (A, n, i+1, k)
                   val RST = mkbintreeFromA (A, n, k+2, j-1)
               in  (case v of
                        V(x) => Node (x, LST, RST)
                      | _  => raise Unexpected_Constructor
                   )
               end
      else raise Invalid_Inorder_Traversal
in              
fun inorderInverse I =
  let 
      val A = Array.fromList I
      val n = Array.length A
  in  mkbintreeFromA (A, n, 0, n-1)
  end
end (* local *)
