fun makeTreeFromRevP1 S = twist  (makeTreeFromP1  (rev S))
