fun reverse0 [] = []
  | reverse0 (x::L') = (reverse0 L')@[x]
