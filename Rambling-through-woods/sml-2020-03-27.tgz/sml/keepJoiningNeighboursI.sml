local
    fun joinNeighboursI [] = []
      | joinNeighboursI [bt] = [bt]
      | joinNeighboursI (bt0::(bt1::btList')) =
        let val ((i,j), rootval0) = root bt0
            val ((k,m), rootval1) = root bt1
        in  if areNeighboursI1 ((i,j), (k, m))
            then let val cii = (i, m)
                     val rt  = Array.sub (arI, j+1) (* Inorder *)
                     val bt = Node ((cii, rt), bt0, bt1)
                 in bt::(joinNeighboursI btList')
                 end
            else bt0::(joinNeighboursI (bt1::btList'))
    end
in
fun keepJoiningNeighboursI [] = raise Invalid_Inorder_Traversal
  | keepJoiningNeighboursI [bt] = bt
  | keepJoiningNeighboursI btList = 
    let val btList1 = joinNeighboursI btList 
    in  keepJoiningNeighboursI btList1
    end (* let *)
end (* local *)
