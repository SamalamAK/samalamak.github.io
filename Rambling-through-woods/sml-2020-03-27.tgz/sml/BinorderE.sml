fun BinorderE (Empty) = [B,E]
  | BinorderE (Node (x, left, right)) = (* non-leaf node *)
    let
        val inLeft = BinorderE left
        val inRight = BinorderE right
    in  B::inLeft@(V(x)::inRight)@[E]
    end
