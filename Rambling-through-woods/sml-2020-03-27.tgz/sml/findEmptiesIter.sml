fun findEmptiesIter (ar) = 
    let val i = ref (n-1)
                (* val NONEs = ref []:((int*int) * 'a option) bintree list ref *)
                val NONEs = ref []                      
     in while (!i >= 0) do
        ( (case Array.sub (ar, !i) of
                NONE => NONEs := (Node (((!i,!i), NONE), Empty, Empty))::(!NONEs)
              | SOME _ => NONEs := !NONEs
          );
          i := (!i)-1
        );
        !NONEs           
    end
