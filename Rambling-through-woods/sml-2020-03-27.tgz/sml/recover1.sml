fun recover ([], []) = Empty
  | recover ((P as r::P'), I) =
    let (* P and I are permutations of each other *)
        val (LP, LI, RP, RI) = partitions (P', I, r)
        val LST = recover (LP, LI)
        val RST = recover (RP, RI)
    in  Node (r, LST, RST)
    end (* let *)
