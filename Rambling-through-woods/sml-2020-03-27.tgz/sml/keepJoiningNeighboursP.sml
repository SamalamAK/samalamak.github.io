local
    fun joinNeighboursP [] = []
      | joinNeighboursP [bt] = [bt]
      | joinNeighboursP (bt0::(bt1::btList')) =
        let val ((i,j), rootval0) = root bt0
            val ((k,m), rootval1) = root bt1
        in  if areNeighboursP1 ((i,j), (k, m))
            then let val cii = (i-1, m)
                     val rt  = Array.sub (arP, i-1)
                     val bt = Node ((cii, rt), bt0, bt1)
                 in bt::(joinNeighboursP btList')
                 end
            else if null (btList') (* list does not reduce *)
            then raise InvalidPreorderTraversal
            else bt0::(joinNeighboursP (bt1::btList'))
    end
in
fun keepJoiningNeighboursP [] = raise InvalidPreorderTraversal
  | keepJoiningNeighboursP [bt] = bt
  | keepJoiningNeighboursP btList = 
    let val btList1 = joinNeighboursP btList 
    in  keepJoiningNeighboursP btList1
    end (* let *)
end (* local *)
