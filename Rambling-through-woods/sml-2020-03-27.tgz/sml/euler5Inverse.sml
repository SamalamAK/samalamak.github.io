exception Invalid_Traversal
exception Invalid_Preorder_Traversal
exception Invalid_Inorder_Traversal
exception Invalid_Postorder_Traversal
exception Out_of_Range
exception Unexpected_Constructor
datatype traversalOrder = PRE | IN | POST | UNDEF | EMP
local
   val sub = Array.sub
   fun traversalOrder (A, n) =
       if n < 2 then UNDEF
       else if n=2 then EMP
       else (* n > 2 => n >= 7 *)
           if (sub (A, 0) = B andalso sub (A, n-1) = E)
           then
            ( case (sub (A, 1), sub (A, n-2))
              of (B,E) => IN
              |  (V(_), E) => PRE
              |  (B, V(_)) => POST
              |  (_, _) => UNDEF
            ) 
            else UNDEF
   fun mkbintreeFromA (A, TO, n, i,j) =
     if i < 0 orelse j >= n orelse j <= i
     then raise Out_of_Range
     else if sub (A, i) = B andalso sub (A, j) = E
     then if j=i+1 then Empty
          else (* |(i, j)| = j-i+1 >= 7 *)
              let fun scanLR (i', m, Bcount, Ecount) =
                    if (Ecount > 0 andalso Bcount = Ecount+1)
                    then i'-1
                    else (case sub (A, i') of
                              B => scanLR (i'+1, m, Bcount+1, Ecount)
                           |  E => scanLR (i'+1, m, Bcount, Ecount+1)
                           | V(_) => scanLR (i'+1, m, Bcount, Ecount)
                          )
                  val k = scanLR (i, j, 0, 0)
                   (*
                      |(i+1, k)| = k-i >= 2
                      |(k+2, j-1)| = (j-1)-(k+2)+1 = j-k-2 >= 2
                   *)
                  val v = (case TO
                            of  PRE => sub (A, i+1)
                             |  IN  => sub (A, k+1)
                             | POST => sub (A, j-1)
                             | _    => raise Unexpected_Constructor
                          )
                   val LST = (case TO
                               of  PRE => mkbintreeFromA (A, TO, n, i+2, k)
                                |  IN  => mkbintreeFromA (A, TO, n, i+1, k)
                                | POST => mkbintreeFromA (A, TO, n, i+1, k)
                                | _    => raise Unexpected_Constructor
                          )
                   val RST = (case TO
                               of  PRE => mkbintreeFromA (A, TO, n, k+1, j-1)
                                |  IN  => mkbintreeFromA (A, TO, n, k+2, j-1)
                                | POST => mkbintreeFromA (A, TO, n, k+1, j-2)
                                | _    => raise Unexpected_Constructor
                          )
               in  (case v of
                        V(x) => Node (x, LST, RST)
                      | _  => raise Unexpected_Constructor
                   )
               end
      else raise Invalid_Traversal
in
fun euler5Inverse L =
  let
      val A = Array.fromList L
      val n = Array.length A
      val TO = traversalOrder (A, n)
  in  ( case TO 
        of UNDEF => raise Invalid_Traversal
        |  EMP   => Empty
        |  _     => mkbintreeFromA (A, TO, n, 0, n-1)
      )
  end

end (* local *)
