exception InvalidPreorderTraversal
fun makeTreeFromP1 [] = raise  InvalidPreorderTraversal
  | makeTreeFromP1 [NONE] = Empty
  | makeTreeFromP1 [_,_] = raise  InvalidPreorderTraversal
  | makeTreeFromP1 [SOME x, NONE, NONE] = Node (x, Empty, Empty)
  | makeTreeFromP1 [_,_,_] =  raise  InvalidPreorderTraversal
  | makeTreeFromP1 P =
    let val arP = Array.fromList P
        val n = Array.length arP
        exception Out_of_Range
        fun areNeighboursP1 ((i,j), (k, m)) =
            let val inRange = (i >= 0) andalso (i < n) andalso
                          (j >= 0) andalso (j < n) andalso
                          (k >= 0) andalso (k < n) andalso
                          (m >= 0) andalso (m < n)
             in if  inRange 
                then if (i>0) andalso (i<=j) andalso (j<=k) andalso (k<= m)
                     then (case Array.sub (arP, i-1) of
                             NONE => false
                           | SOME _ => (k=j+1)
                          )
                     else false
                else raise Out_of_Range
             end
        fun findEmptiesIter (ar) = 
            let val i = ref (n-1)
                        (* val NONEs = ref []:((int*int) * 'a option) bintree list ref *)
                        val NONEs = ref []                      
             in while (!i >= 0) do
                ( (case Array.sub (ar, !i) of
                        NONE => NONEs := (Node (((!i,!i), NONE), Empty, Empty))::(!NONEs)
                      | SOME _ => NONEs := !NONEs
                  );
                  i := (!i)-1
                );
                !NONEs           
            end
        val NONEs = findEmptiesIter (arP)
        local
            fun joinNeighboursP [] = []
              | joinNeighboursP [bt] = [bt]
              | joinNeighboursP (bt0::(bt1::btList')) =
                let val ((i,j), rootval0) = root bt0
                    val ((k,m), rootval1) = root bt1
                in  if areNeighboursP1 ((i,j), (k, m))
                    then let val cii = (i-1, m)
                             val rt  = Array.sub (arP, i-1)
                             val bt = Node ((cii, rt), bt0, bt1)
                         in bt::(joinNeighboursP btList')
                         end
                    else if null (btList') (* list does not reduce *)
                    then raise InvalidPreorderTraversal
                    else bt0::(joinNeighboursP (bt1::btList'))
            end
        in
        fun keepJoiningNeighboursP [] = raise InvalidPreorderTraversal
          | keepJoiningNeighboursP [bt] = bt
          | keepJoiningNeighboursP btList = 
            let val btList1 = joinNeighboursP btList 
            in  keepJoiningNeighboursP btList1
            end (* let *)
        end (* local *)
        val bt = keepJoiningNeighboursP NONEs
        exception Unexpected_Empty_Node
        exception Unexpected_Node_Value
        fun eraseIndices Empty = raise Empty_bintree
          | eraseIndices (Node (((i, j), NONE), Empty, Empty)) = 
              if (i=j) then Empty else raise Unexpected_Empty_Node
          | eraseIndices (Node (((i, j), x), LST, RST)) =
              let val left =  eraseIndices LST
                  val right = eraseIndices RST
               in ( case x of 
                         NONE => raise Unexpected_Node_Value
                       | SOME y => Node (y, left, right)
                  )
              end
    in  (eraseIndices bt)
    end
