local fun pre (Empty, Llist)  = Llist
        | pre (Node (N, LST, RST), Llist) = 
          let val Mlist = pre (RST, Llist)
              val Nlist = pre (LST, Mlist)
          in  N::Nlist
          end
in fun preorder T = pre (T, [])
end
