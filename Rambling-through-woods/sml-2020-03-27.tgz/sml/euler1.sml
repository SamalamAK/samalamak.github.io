fun eulerTour1 (Empty) = (nil, nil, nil)
  | eulerTour1 (Node (x, left, right)) =
        let
                val (preL, inL, postL) = eulerTour1 left
                val (preR, inR, postR) = eulerTour1 right
        in (x::preL@preR, inL@(x::inR), postL@postR@[x])
        end
fun preorder T = #1 (eulerTour1 T)
fun inorder T = #2  (eulerTour1 T)
fun postorder T = #3  (eulerTour1 T)
