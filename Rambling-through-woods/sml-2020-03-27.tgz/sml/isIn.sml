fun  is_in (x, L) = List.exists (fn y => x=y) L
