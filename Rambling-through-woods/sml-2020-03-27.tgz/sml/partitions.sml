local
    fun dissemble ([], LI, RI, LP, RP) = (LP, RP):''a list * ''a list
      | dissemble ((h::t), LI, RI, LP, RP) =
        if  is_in (h, LI)
        then dissemble (t, LI, RI, (h::LP), RP)
        else (* it must be in RI *)
            dissemble (t, LI, RI, LP, (h::RP))
in fun partitions (P', I, r) =
  let
      val (LI, RI) = split (I, r)
      val (LP, RP) = dissemble (P', LI, RI, [], [])
  in (rev LP, LI, rev RP, RI)
  end (* let *)
end (* local *)
