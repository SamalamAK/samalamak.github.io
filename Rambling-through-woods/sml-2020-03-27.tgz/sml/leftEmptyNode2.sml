fun leftSubtree Empty = raise Empty_bintree
  | leftSubtree (Node (_, LST, _)) = LST
