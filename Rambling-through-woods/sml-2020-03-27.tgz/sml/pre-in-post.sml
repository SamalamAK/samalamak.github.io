datatype 'a traversal = PRE of 'a | IN of 'a | POST of 'a
