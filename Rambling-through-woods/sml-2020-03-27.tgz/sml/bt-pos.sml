fun btpos Empty = Empty
  | btpos (Node (x, L, R)) =
           let val posL = btpos L
               val posR = btpos R
           in  Node ((x,""), (BTmap0 posL), (BTmap1 posR))
           end
