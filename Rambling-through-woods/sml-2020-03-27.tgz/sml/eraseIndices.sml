exception Unexpected_Empty_Node
exception Unexpected_Node_Value
fun eraseIndices Empty = raise Empty_bintree
  | eraseIndices (Node (((i, j), NONE), Empty, Empty)) = 
      if (i=j) then Empty else raise Unexpected_Empty_Node
  | eraseIndices (Node (((i, j), x), LST, RST)) =
      let val left =  eraseIndices LST
          val right = eraseIndices RST
       in ( case x of 
                 NONE => raise Unexpected_Node_Value
               | SOME y => Node (y, left, right)
          )
      end
