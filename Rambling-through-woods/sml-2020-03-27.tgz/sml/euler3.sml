fun eulerTour3 (Empty) = ([NONE], [NONE], [NONE])
  | eulerTour3 (Node (x, left, right)) =
        let
                val (preL, inL, postL) = eulerTour3 left
                val (preR, inR, postR) = eulerTour3 right
        in ((SOME x)::preL@preR, inL@((SOME x)::inR), postL@postR@[(SOME x)])
        end
fun preorder bt = #1 (eulerTour3 bt) 
fun inorder bt = #2 (eulerTour3 bt) 
fun postorder bt = #3 (eulerTour3 bt) 
