fun size Empty = 0
  | size (Node (_, left, right)) =
    let
        val ls = size left
        val rs = size right
     in 1 + ls + rs
    end

