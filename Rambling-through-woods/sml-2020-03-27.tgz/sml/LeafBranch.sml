datatype 'a LBbintree =
         Leaf of 'a |
         Branch of 'a * 'a bintree * 'a bintree

