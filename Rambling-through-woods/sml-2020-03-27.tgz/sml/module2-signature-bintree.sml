signature BINTREE =
sig
    datatype ''a bintree = Empty |
                          Node of ''a * ''a bintree * ''a bintree
    datatype ''a BEtype = B | E | V of ''a
    val root        : ''a bintree -> ''a
    val leftSubtree : ''a bintree -> ''a bintree
    val rightSubtree: ''a bintree -> ''a bintree
    val height      : ''a bintree -> int
    val size        : ''a bintree -> int
    val isLeaf      : ''a bintree -> bool
    val BTmap       : (''a -> ''b) -> ''a bintree -> ''b bintree
    val euler       : ''a bintree -> ''a BEtype list * ''a BEtype list * ''a BEtype list
    val preorder    : ''a bintree -> ''a BEtype list
    val inorder     : ''a bintree -> ''a BEtype list
    val postorder   : ''a bintree -> ''a BEtype list
    exception Invalid_Traversal
    val recover     : ''a BEtype list -> ''a bintree
end (* sig *)
