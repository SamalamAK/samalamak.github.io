fun eulerTour5 (Empty) = ([B,E], [B,E], [B,E])
  | eulerTour5 (Node (x, left, right)) = (* non-leaf node *)
    let
        val (preL, inL, postL) = eulerTour5 left
        val (preR, inR, postR) = eulerTour5 right
    in (B::V(x)::preL@preR@[E], B::inL@(V(x)::inR)@[E], B::postL@postR@[V(x),E])
    end
fun preorder bt = #1 (eulerTour5 bt) 
fun inorder bt = #2 (eulerTour5 bt) 
fun postorder bt = #3 (eulerTour5 bt) 
