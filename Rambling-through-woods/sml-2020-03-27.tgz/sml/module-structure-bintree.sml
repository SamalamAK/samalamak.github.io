structure Bintree : BINTREE =
struct
        datatype 'a bintree =
                 Empty |
                 Node of 'a * 'a bintree * 'a bintree
        datatype 'a bintree =
                 Empty |
                 Node of 'a * 'a bintree * 'a bintree
        exception Empty_bintree
        fun root Empty = raise Empty_bintree
          | root (Node (x, _, _)) = x
        fun leftSubtree Empty = raise Empty_bintree
          | leftSubtree (Node (_, LST, _)) = LST
        fun rightSubtree Empty = raise Empty_bintree
          | rightSubtree (Node (_, _, RST)) = RST
        val max = Int.max
        fun height Empty = 0
          | height (Node (_, left, right)) =
            let
                val lh = height left
                val rh = height right
             in 1 + max(lh, rh)
            end

        fun size Empty = 0
          | size (Node (_, left, right)) =
            let
                val ls = size left
                val rs = size right
             in 1 + ls + rs
            end

        fun isLeaf Empty = false
          | isLeaf (Node (_, Empty, Empty)) = true
          | isLeaf _ = false 
                                                                                   
        fun twist Empty = Empty
          | twist (Node (x, LST, RST)) =
            let
                val LST' = twist RST
                val RST' = twist LST
            in  Node (x, LST', RST')
            end     
        fun BTmap F =
            let fun BTM Empty = Empty
                  | BTM (Node (x, left, right)) = Node ((F x), BTM (left), BTM (right))
            in  BTM
            end
        fun eulerTour3 (Empty) = ([NONE], [NONE], [NONE])
          | eulerTour3 (Node (x, left, right)) =
                let
                        val (preL, inL, postL) = eulerTour3 left
                        val (preR, inR, postR) = eulerTour3 right
                in ((SOME x)::preL@preR, inL@((SOME x)::inR), postL@postR@[(SOME x)])
                end
        fun preorder bt = #1 (eulerTour3 bt) 
        fun inorder bt = #2 (eulerTour3 bt) 
        fun postorder bt = #3 (eulerTour3 bt) 
        val euler = eulerTour3          
        exception InvalidPreorderTraversal
        fun makeTreeFromP1 [] = raise  InvalidPreorderTraversal
          | makeTreeFromP1 [NONE] = Empty
          | makeTreeFromP1 [_,_] = raise  InvalidPreorderTraversal
          | makeTreeFromP1 [SOME x, NONE, NONE] = Node (x, Empty, Empty)
          | makeTreeFromP1 [_,_,_] =  raise  InvalidPreorderTraversal
          | makeTreeFromP1 P =
            let val arP = Array.fromList P
                val n = Array.length arP
                exception Out_of_Range
                fun areNeighboursP1 ((i,j), (k, m)) =
                    let val inRange = (i >= 0) andalso (i < n) andalso
                                  (j >= 0) andalso (j < n) andalso
                                  (k >= 0) andalso (k < n) andalso
                                  (m >= 0) andalso (m < n)
                     in if  inRange 
                        then if (i>0) andalso (i<=j) andalso (j<=k) andalso (k<= m)
                             then (case Array.sub (arP, i-1) of
                                     NONE => false
                                   | SOME _ => (k=j+1)
                                  )
                             else false
                        else raise Out_of_Range
                     end
                fun findEmptiesIter (ar) = 
                    let val i = ref (n-1)
                                (* val NONEs = ref []:((int*int) * 'a option) bintree list ref *)
                                val NONEs = ref []                      
                     in while (!i >= 0) do
                        ( (case Array.sub (ar, !i) of
                                NONE => NONEs := (Node (((!i,!i), NONE), Empty, Empty))::(!NONEs)
                              | SOME _ => NONEs := !NONEs
                          );
                          i := (!i)-1
                        );
                        !NONEs           
                    end
                val NONEs = findEmptiesIter (arP)
                local
                    fun joinNeighboursP [] = []
                      | joinNeighboursP [bt] = [bt]
                      | joinNeighboursP (bt0::(bt1::btList')) =
                        let val ((i,j), rootval0) = root bt0
                            val ((k,m), rootval1) = root bt1
                        in  if areNeighboursP1 ((i,j), (k, m))
                            then let val cii = (i-1, m)
                                     val rt  = Array.sub (arP, i-1)
                                     val bt = Node ((cii, rt), bt0, bt1)
                                 in bt::(joinNeighboursP btList')
                                 end
                            else if null (btList') (* list does not reduce *)
                            then raise InvalidPreorderTraversal
                            else bt0::(joinNeighboursP (bt1::btList'))
                    end
                in
                fun keepJoiningNeighboursP [] = raise InvalidPreorderTraversal
                  | keepJoiningNeighboursP [bt] = bt
                  | keepJoiningNeighboursP btList = 
                    let val btList1 = joinNeighboursP btList 
                    in  keepJoiningNeighboursP btList1
                    end (* let *)
                end (* local *)
                val bt = keepJoiningNeighboursP NONEs
                exception Unexpected_Empty_Node
                exception Unexpected_Node_Value
                fun eraseIndices Empty = raise Empty_bintree
                  | eraseIndices (Node (((i, j), NONE), Empty, Empty)) = 
                      if (i=j) then Empty else raise Unexpected_Empty_Node
                  | eraseIndices (Node (((i, j), x), LST, RST)) =
                      let val left =  eraseIndices LST
                          val right = eraseIndices RST
                       in ( case x of 
                                 NONE => raise Unexpected_Node_Value
                               | SOME y => Node (y, left, right)
                          )
                      end
            in  (eraseIndices bt)
            end
        val preorderInverse = makeTreeFromP1
        fun makeTreeFromRevP1 S = twist  (makeTreeFromP1  (rev S))
        val postorderInverse = makeTreeFromRevP1
end (* struct *)

