exception InvalidPreorderTraversal
fun makeTreeFromP0 [] = raise  InvalidPreorderTraversal
  | makeTreeFromP0 [NONE] = Empty
  | makeTreeFromP0 [_,_] = raise  InvalidPreorderTraversal
  | makeTreeFromP0 [SOME x, NONE, NONE] = Node (x, Empty, Empty)
  | makeTreeFromP0 [_,_,_] =  raise  InvalidPreorderTraversal
  | makeTreeFromP0 (h::t) =
    ( case h of
          NONE => raise  InvalidPreorderTraversal
        | SOME x =>
          let
              val (LST, RST) = makeTwoTrees t
          in  Node (x, LST, RST)
          end
    )
