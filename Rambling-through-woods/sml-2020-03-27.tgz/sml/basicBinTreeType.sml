datatype 'a bintree =
         Empty |
         Node of 'a * 'a bintree * 'a bintree
exception Empty_bintree
fun root Empty = raise Empty_bintree
  | root (Node (x, _, _)) = x
fun leftSubtree Empty = raise Empty_bintree
  | leftSubtree (Node (_, LST, _)) = LST
fun rightSubtree Empty = raise Empty_bintree
  | rightSubtree (Node (_, _, RST)) = RST
val max = Int.max
fun height Empty = 0
  | height (Node (_, left, right)) =
    let
        val lh = height left
        val rh = height right
     in 1 + max(lh, rh)
    end

fun size Empty = 0
  | size (Node (_, left, right)) =
    let
        val ls = size left
        val rs = size right
     in 1 + ls + rs
    end

fun isLeaf Empty = false
  | isLeaf (Node (_, Empty, Empty)) = true
  | isLeaf _ = false 
                                                                           
