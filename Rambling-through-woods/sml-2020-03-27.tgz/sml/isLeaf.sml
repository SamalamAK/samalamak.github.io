fun isLeaf Empty = false
  | isLeaf (Node (_, Empty, Empty)) = true
  | isLeaf _ = false 
