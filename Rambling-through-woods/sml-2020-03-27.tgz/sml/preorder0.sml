fun preorder0 Empty = []
  | preorder0 (Node(x, LST, RST)) = 
              x::(preorder0 LST) @ (preorder0 RST)
