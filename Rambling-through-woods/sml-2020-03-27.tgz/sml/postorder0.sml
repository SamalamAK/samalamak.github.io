fun postorder0 Empty = nil
  | postorder1 (Node (x, LST, RST)) = 
       (postorder0 LST) @ (postorder0 RST) @ [x]
