datatype 'a bintree012 =
      Zero of 'a |
      One of 'a * 'a bintree012 |
      Two of 'a * 'a bintree012 * 'a bintree012

