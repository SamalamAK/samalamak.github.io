val max = Int.max
fun height Empty = 0
  | height (Node (_, left, right)) =
    let
        val lh = height left
        val rh = height right
     in 1 + max(lh, rh)
    end

