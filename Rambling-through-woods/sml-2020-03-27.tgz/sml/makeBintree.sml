exception invalid_nodelist of string
exception No_root
exception Multiple_roots                          
fun makeBintree [] = Empty
  | makeBintree [(a,"")] = Node(a, Empty, Empty)
  | makeBintree [(_, _)] = raise invalid_nodelist ("ERROR: Expected empty string in position")
  | makeBintree nl = (* nl has at least two elements *)
    let
        val (rt, nl0, nl1) = partInto3 nl ([], [], [])
        val valrt = if List.null (rt) then raise No_root
                    else if (List.length rt) = 1 then (#1 (hd rt))
                    else raise Multiple_roots
        val nl0' = List.map strip1 nl0
        val nl1' = List.map strip1 nl1
        val t0 = makeBintree nl0'
        val t1 = makeBintree nl1'
    in
        Node (valrt, t0, t1)
    end (* let *)
