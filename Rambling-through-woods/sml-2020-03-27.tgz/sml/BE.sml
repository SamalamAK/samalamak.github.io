datatype 'a BEtype = B | E | V of 'a
