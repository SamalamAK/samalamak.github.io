fun eulerTour4 (Empty) = ([NONE], [NONE], [NONE])
  | eulerTour4 (Node (x, Empty, Empty)) = (* leaf node *)
     ([SOME (x,0), NONE, NONE], [NONE, SOME (x,0), NONE], [NONE, NONE, SOME (x,0)])
  | eulerTour4 (Node (x, left, right)) = (* non-leaf node *)
    let
        val (preL, inL, postL) = eulerTour4 left
        val (preR, inR, postR) = eulerTour4 right
    in ((SOME (x,1))::preL@preR, inL@((SOME (x,1))::inR), postL@postR@[(SOME (x,1))])
    end
fun preorder bt = #1 (eulerTour4 bt) 
fun inorder bt = #2 (eulerTour4 bt) 
fun postorder bt = #3 (eulerTour4 bt) 
