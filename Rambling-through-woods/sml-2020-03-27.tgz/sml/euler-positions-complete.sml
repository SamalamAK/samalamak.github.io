datatype 'a bintree =
         Empty |
         Node of 'a * 'a bintree * 'a bintree                
fun prefix s (x, p) = (x, s^p)
fun prefix0 (x, p) = prefix "0" (x,p)
fun prefix1 (x, p)= prefix "1" (x,p)
fun eulerTour2 Empty = (nil, nil, nil)
  | eulerTour2 (Node (x, left, right)) =
    let
        val (preL, inL, postL) = eulerTour2 left
        val (preR, inR, postR) = eulerTour2 right
    in ((x, "")::((map prefix0 preL)@(map prefix1 preR)),
        (map prefix0 inL)@((x,"")::(map prefix1 inR)),
        (map prefix0 postL)@(map prefix1 postR)@[(x,"")]
       )
    end
