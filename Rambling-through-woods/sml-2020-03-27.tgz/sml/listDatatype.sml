datatype 'a list = nil | :: of 'a * 'a list
