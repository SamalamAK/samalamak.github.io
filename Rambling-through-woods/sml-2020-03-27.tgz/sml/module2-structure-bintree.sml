structure Bintree : BINTREE =
struct
        datatype 'a bintree =
                 Empty |
                 Node of 'a * 'a bintree * 'a bintree
        exception Empty_bintree
        fun root Empty = raise Empty_bintree
          | root (Node (x, _, _)) = x
        fun leftSubtree Empty = raise Empty_bintree
          | leftSubtree (Node (_, LST, _)) = LST
        fun rightSubtree Empty = raise Empty_bintree
          | rightSubtree (Node (_, _, RST)) = RST
        val max = Int.max
        fun height Empty = 0
          | height (Node (_, left, right)) =
            let
                val lh = height left
                val rh = height right
             in 1 + max(lh, rh)
            end

        fun size Empty = 0
          | size (Node (_, left, right)) =
            let
                val ls = size left
                val rs = size right
             in 1 + ls + rs
            end

        fun isLeaf Empty = false
          | isLeaf (Node (_, Empty, Empty)) = true
          | isLeaf _ = false 
                                                                                   
        fun twist Empty = Empty
          | twist (Node (x, LST, RST)) =
            let
                val LST' = twist RST
                val RST' = twist LST
            in  Node (x, LST', RST')
            end     
        fun BTmap F =
            let fun BTM Empty = Empty
                  | BTM (Node (x, left, right)) = Node ((F x), BTM (left), BTM (right))
            in  BTM
            end
        datatype 'a BEtype = B | E | V of 'a
        fun eulerTour5 (Empty) = ([B,E], [B,E], [B,E])
          | eulerTour5 (Node (x, left, right)) = (* non-leaf node *)
            let
                val (preL, inL, postL) = eulerTour5 left
                val (preR, inR, postR) = eulerTour5 right
            in (B::V(x)::preL@preR@[E], B::inL@(V(x)::inR)@[E], B::postL@postR@[V(x),E])
            end
        fun preorder bt = #1 (eulerTour5 bt) 
        fun inorder bt = #2 (eulerTour5 bt) 
        fun postorder bt = #3 (eulerTour5 bt) 
        val euler = eulerTour5          
        exception Invalid_Traversal
        exception Invalid_Preorder_Traversal
        exception Invalid_Inorder_Traversal
        exception Invalid_Postorder_Traversal
        exception Out_of_Range
        exception Unexpected_Constructor
        datatype traversalOrder = PRE | IN | POST | UNDEF | EMP
        local
           val sub = Array.sub
           fun traversalOrder (A, n) =
               if n < 2 then UNDEF
               else if n=2 then EMP
               else (* n > 2 => n >= 7 *)
                   if (sub (A, 0) = B andalso sub (A, n-1) = E)
                   then
                    ( case (sub (A, 1), sub (A, n-2))
                      of (B,E) => IN
                      |  (V(_), E) => PRE
                      |  (B, V(_)) => POST
                      |  (_, _) => UNDEF
                    ) 
                    else UNDEF
           fun mkbintreeFromA (A, TO, n, i,j) =
             if i < 0 orelse j >= n orelse j <= i
             then raise Out_of_Range
             else if sub (A, i) = B andalso sub (A, j) = E
             then if j=i+1 then Empty
                  else (* |(i, j)| = j-i+1 >= 7 *)
                      let fun scanLR (i', m, Bcount, Ecount) =
                            if (Ecount > 0 andalso Bcount = Ecount+1)
                            then i'-1
                            else (case sub (A, i') of
                                      B => scanLR (i'+1, m, Bcount+1, Ecount)
                                   |  E => scanLR (i'+1, m, Bcount, Ecount+1)
                                   | V(_) => scanLR (i'+1, m, Bcount, Ecount)
                                  )
                          val k = scanLR (i, j, 0, 0)
                           (*
                              |(i+1, k)| = k-i >= 2
                              |(k+2, j-1)| = (j-1)-(k+2)+1 = j-k-2 >= 2
                           *)
                          val v = (case TO
                                    of  PRE => sub (A, i+1)
                                     |  IN  => sub (A, k+1)
                                     | POST => sub (A, j-1)
                                     | _    => raise Unexpected_Constructor
                                  )
                           val LST = (case TO
                                       of  PRE => mkbintreeFromA (A, TO, n, i+2, k)
                                        |  IN  => mkbintreeFromA (A, TO, n, i+1, k)
                                        | POST => mkbintreeFromA (A, TO, n, i+1, k)
                                        | _    => raise Unexpected_Constructor
                                  )
                           val RST = (case TO
                                       of  PRE => mkbintreeFromA (A, TO, n, k+1, j-1)
                                        |  IN  => mkbintreeFromA (A, TO, n, k+2, j-1)
                                        | POST => mkbintreeFromA (A, TO, n, k+1, j-2)
                                        | _    => raise Unexpected_Constructor
                                  )
                       in  (case v of
                                V(x) => Node (x, LST, RST)
                              | _  => raise Unexpected_Constructor
                           )
                       end
              else raise Invalid_Traversal
        in
        fun euler5Inverse L =
          let
              val A = Array.fromList L
              val n = Array.length A
              val TO = traversalOrder (A, n)
          in  ( case TO 
                of UNDEF => raise Invalid_Traversal
                |  EMP   => Empty
                |  _     => mkbintreeFromA (A, TO, n, 0, n-1)
              )
          end

        end (* local *)
        val recover = euler5Inverse
end (* struct *)
