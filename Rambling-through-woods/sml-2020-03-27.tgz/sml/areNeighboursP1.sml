exception Out_of_Range
fun areNeighboursP1 ((i,j), (k, m)) =
    let val inRange = (i >= 0) andalso (i < n) andalso
                  (j >= 0) andalso (j < n) andalso
                  (k >= 0) andalso (k < n) andalso
                  (m >= 0) andalso (m < n)
     in if  inRange 
        then if (i>0) andalso (i<=j) andalso (j<=k) andalso (k<= m)
             then (case Array.sub (arP, i-1) of
                     NONE => false
                   | SOME _ => (k=j+1)
                  )
             else false
        else raise Out_of_Range
     end
