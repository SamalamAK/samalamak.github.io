fun findEmpties PIT = 
    let fun findNONEs ([], _, T) = T
          | findNONEs ((NONE::t), i, T) =
            findNONEs (t, i+1, Leaf ((i,i), List.nth (PIT, i))::T)
        val NONEs = findNONEs (PIT, 0, [])
    in
       rev NONEs
    end
