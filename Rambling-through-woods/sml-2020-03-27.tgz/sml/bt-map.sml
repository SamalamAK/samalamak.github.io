fun BTmap F =
    let fun BTM Empty = Empty
          | BTM (Node (x, left, right)) = Node ((F x), BTM (left), BTM (right))
    in  BTM
    end
