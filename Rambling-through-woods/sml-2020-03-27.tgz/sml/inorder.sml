local fun ino (Empty, Llist) = Llist
        | ino (Node (N, LST, RST), Llist) = 
          let val Mlist = ino (RST, Llist)
              val Nlist = ino (LST, N::Mlist)
          in  Nlist
          end
in fun inorder T = ino (T, [])
end
