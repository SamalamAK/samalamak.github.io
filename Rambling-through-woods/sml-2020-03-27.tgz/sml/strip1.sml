local 
    exception striphd_empty
    fun striphd s =
      let val l = String.size s 
      in if l = 0 then raise striphd_empty
         else substring (s, 1, l-1)               
      end
in
fun strip1 (a,b) = (a, (striphd b))
end
